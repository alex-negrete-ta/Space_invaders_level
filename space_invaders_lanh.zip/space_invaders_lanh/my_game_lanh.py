import pygame
import os
import random as rand
import constants as con


# Define Ship Base Class (Base sprite for the entire game).
class Ship(pygame.sprite.DirtySprite):
        def __init__(self, x_pos, y_pos, image, explosion_group, health):
                '''
                Description: Base Ship Class

                Attributes:
                x_pos (int/float): the X position of the sprite.
                y_pos (int/float): the y position of the sprite.
                image (str): a path string to the desired image.  
                explosion_group (obj): Game over animation.
                health (int): Attribute of the health of the sprite.
                
                Output:
                A blueprint to for any ship class.  
                '''
                pygame.sprite.DirtySprite.__init__(self)
                self.x_pos = x_pos
                self.y_pos = y_pos 
                self.image = pygame.transform.smoothscale(
                        pygame.image.load(image), (30,30)
                                                        )
                self.rect = self.image.get_rect(
                        center = (x_pos,y_pos)
                                                )
                self.health_start = health
                self.health_remain = health
                self.explosion_group = explosion_group

                    
# Define Hero ship Class (The users gameplay).
class Hero (Ship):
        '''
        Description:
        Inherits the Ship class and determines the attributes of the hero.

        Attributes:
        x_pos (int/float): the X position of the sprite.
        y_pos (int/float): the y position of the sprite.
        image (str): a path string to the desired image.
        laser_group (obj): Takes in the object of the laser.
        colllide_with_group (obj): The objects that colllides with the ship.
        explosion_group (obj): Game over animation.
        health (int): Attribute of the health of the sprite.
        reoload (int): Speed of sprites shooting.
        speed (int): Movement speed.


        Output:
        An object of the players sprite.
        '''
        def __init__(self,
                     x_pos,
                     y_pos, 
                     image,
                     laser_group, 
                     collide_with_group,
                     explosion_group,
                     health = 4,
                     reload=250,
                     speed=10
                     ):
                Ship.__init__ (self, x_pos, y_pos,image,explosion_group,health)
                self.laser_group = laser_group 
                self.collide_group = collide_with_group
                self.last_shot = pygame.time.get_ticks()
                self.reload = reload
                self.speed = speed
         
        def update(self): 
                # Set key inputs.
                key = pygame.key.get_pressed()
                if key [pygame.K_LEFT] and self.rect.left > 2:
                        self.rect.x -= self.speed
                if key[pygame.K_RIGHT] and self.rect.right < con.width - 5:
                        self.rect.x += self.speed
                
                # Shoot laser.
                current_time = pygame.time.get_ticks()
                if (key[pygame.K_SPACE]and current_time - self.last_shot 
                > self.reload):
                        hero_laser = Laser(
                                self.rect.x,
                                self.rect.top, 
                                con.hero_laser_path,
                                self.collide_group
                                      )
                        self.laser_group.add(hero_laser)
                        self.last_shot = current_time
                
                # Game Over
                if self.health_remain == 0:
                        explosion = Explosion (
                                        self.rect.centerx, 
                                        self.rect.centery, 
                                        con.explosion_path,
                                        20
                                               )
                        self.kill()
                        self.explosion_group.add(explosion)
                self.dirty = 1

        
# Define Enemy ship Class.
class Enemy (Ship):
        '''
        Description:
        Inherits the Ship class and determines the attributes of the enemy.

        Attributes:
        x_pos (int/float): the X position of the sprite.
        y_pos (int/float): the y position of the sprite.
        image (str): a path string to the desired image.
        explosion_group (obj): Game over animation.
        health (int): Attribute of the health of the sprite.

        Output:
        An enemy blueprint with timed animation.
        '''
        def __init__(self,x_pos,y_pos, image,explosion_group,health = 1):
                Ship.__init__ (self,x_pos, y_pos, image, explosion_group, health)
                self.move_counter = 0
                self.move_direction = 1

        def update(self):
                # Set enemy animation based on counter.
                self.rect.x += self.move_direction
                self.move_counter += 1

                if abs(self.move_counter) > (con.width *.1):
                        self.move_direction *= -1
                        self.move_counter *= self.move_direction                        
                 
                # Game Over
                if self.health_remain == 0:
                        explosion = Explosion (
                                        self.rect.centerx, 
                                        self.rect.centery, 
                                        con.explosion_path
                                               )
                        self.kill()
                        self.explosion_group.add(explosion)
        
                        
                self.dirty = 1


# Define Laser Class.
class Laser(pygame.sprite.DirtySprite):
        '''
        Description:
        Creates a Laser Sprite to attach both the enemy and hero.

        Attributes:
        x_pos (int/float): the X position of the sprite.
        y_pos (int/float): the y position of the sprite.
        image (str): a path string to the desired image.
        collide_with_group (obj): the object to crash into.
        speed (int): velocity of the sprite
        direction (bol): Is it going up (true) or down (false).

        Output:
        A laser sprite.
        '''
        def __init__(self, 
                     x_pos, 
                     y_pos, 
                     image, 
                     collide_with_group, 
                     speed = 5, 
                     direction = True
                     ):
                pygame.sprite.DirtySprite.__init__(self)
                self.image = pygame.transform.scale(
                                 pygame.image.load(image),(2,5)
                                                    )
                self.rect = self.image.get_rect (center = (x_pos,y_pos))
                self.collide_group = collide_with_group
                self.speed = speed
                self.direction = direction
               
        
        def update (self):
                #Determines the bounding box of the laser before it kills.
                if self.direction:
                        self.rect.y -= self.speed
                        if self.rect.bottom < 0:
                                self.kill()
                       
                else:
                        self.rect.y += self.speed
                        if self.rect.bottom > con.height:
                                self.kill()

                # Take one health from a collisionable object.
                collision_list =pygame.sprite.spritecollide(self, 
                                                       self.collide_group, 
                                                       False,
                                                       )
                if len(collision_list) > 0:
                        self.kill()
                        collision_list[0].health_remain -=1
                      
                print(collision_list)

                self.dirty = 1


# Explosion Class.
class Explosion (pygame.sprite.DirtySprite):
        '''
        Description:
        Sprite to show the destruction of an object.

        Attributes:
        x (int/float): the X position of the sprite.
        y (int/float): the y position of the sprite.
        image (str): a path string to the desired image.
        explosion (int): Explosion speed.

        Output:
        An explosion event.
        '''
        def __init__(self, x, y, image,explosion=2):
                pygame.sprite.DirtySprite.__init__(self)
                self.image = pygame.image.load(image)
                self.rect = self.image.get_rect()
                self.rect.center = [x,y]
                self.counter = 0
                self.explosion_speed = explosion

        def update(self):
                self.counter += 1
                self.image = self.image
                if self.counter >= self.explosion_speed:
                        self.kill() 
                

        


# Main Function that runs the program.
def main():
        # Set the Game run settings. Attaches image to window.
        run = True
        fps =60
        clock = pygame.time.Clock()
        
        # Calling the background.
        background = pygame.Surface(con.win.get_size())
        background.blit(con.background_image,(0,0))
        
        # Setting the center of the screen.
        center_x = int(con.width/2)
        center_y = int(con.width/2)

        # Hero and Enemy dirty groups, hero ship object and laser timer.
        hero_ship_group = pygame.sprite.LayeredDirty()
        enemy_ship_group = pygame.sprite.LayeredDirty()
        hero_laser_group = pygame.sprite.LayeredDirty()
        enemy_laser_group = pygame.sprite.LayeredDirty()
        explosion_group = pygame.sprite.LayeredDirty()
        ''' Hero ship object.'''
        hero_ship = Hero(
                        center_x, 
                        (center_y + 200), 
                        con.hero_image_path, 
                        hero_laser_group,
                        enemy_ship_group,
                        explosion_group,
                        health = 4
                         )
        hero_ship_group.add(hero_ship)

        last_enemy_shot = pygame.time.get_ticks()

        # Enemy Objects.
        number_columns = 9
        number_rows  = 5
        enemy_ship_images = [con.enemy_image_path,con.boss_image_path]
        for column in range(number_columns):
                for row in range(number_rows):
                       enemy_ship = Enemy(
                                (50+ column * 50),
                                (50 + row * 50),
                                rand.choice(enemy_ship_images),
                                explosion_group,
                                rand.randrange(1,4)
                                )
                       enemy_ship_group.add(enemy_ship) 
                        
        

        # While loop that updates the events of the game.
        hero_ship_group.clear(con.win, background)
        enemy_ship_group.clear(con.win,background)
        hero_laser_group.clear(con.win,background)
        enemy_laser_group.clear(con.win,background)
        explosion_group.clear(con.win,background)
        while run:
                # Loop through all the events and exit on QUIT.
                for event in pygame.event.get():
                        if event.type == pygame.QUIT:
                                quit()

                # Create enemy 
                current_time = pygame.time.get_ticks()
                
                if (current_time - last_enemy_shot > 400 
                and len(enemy_ship_group) > 0 
                and len(enemy_laser_group) < 3 
                and len(hero_ship_group) >0):
                        enemy = rand.choice(enemy_ship_group.sprites())
                        enemy_laser = Laser(
                                        enemy.rect.centerx,
                                        enemy.rect.top, 
                                        con.enemy_laser_path,
                                        hero_ship_group, 
                                        direction = False
                                        )
                        enemy_laser_group.add(enemy_laser)
                        last_enemy_shot = current_time

                # Update Sprite Groups
                hero_ship_group.update()
                enemy_ship_group.update()
                hero_laser_group.update()
                enemy_laser_group.update()
                explosion_group.update()
        
                # Drawing the ships.
                hero_ship_group.draw(con.win)
                enemy_ship_group.draw(con.win)
                hero_laser_group.draw(con.win)
                enemy_laser_group.draw(con.win)
                explosion_group.draw(con.win)
                


                red_bar =pygame.draw.rect(con.win,
                                          (255,0,0),
                                          (20, con.height -5, 30,15)
                                          )
                green_bar =pygame.draw.rect(con.win, 
                                            (0,255,0),
                                            (20, con.height -5, 
                                             30 * (hero_ship.health_remain / 
                                                   hero_ship.health_start),
                                             15)
                                            )

                # Updating the game tick in fps values, and updating display.
                clock.tick(fps)
                
                pygame.display.update()

if __name__ == '__main__':
        main()

