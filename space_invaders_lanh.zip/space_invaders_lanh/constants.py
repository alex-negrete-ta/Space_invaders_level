import pygame
import os

# Define game constants.
''' Resolution.'''
width, height = 500, 500

''' Display and Background.'''
win = pygame.display.set_mode(size= (width,height))
background_image = pygame.transform.scale(
                pygame.image.load(
                                  os.path.join('02_Assets','background.png')),
                                  (width,height)
                                   )
        
# Load Source Images.
hero_image_path = os.path.join('02_Assets','Hero_Sprite.png')
enemy_image_path = os.path.join('02_Assets','Enemy_Sprite.png')
boss_image_path = os.path.join('02_Assets','Boss_Sprite.png')
hero_laser_path = os.path.join('02_Assets','laser_hero.png')
enemy_laser_path = os.path.join('02_Assets','laser_enemy.png')
explosion_path = os.path.join('02_Assets','Smoke_Hero_Sprite.png')


